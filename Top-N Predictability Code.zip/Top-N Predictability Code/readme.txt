Dataset：
https://www.dropbox.com/sh/7qdquluflk032ot/AACoz2Go49q1mTpXYGe0gaANa?dl=0
https://www.dunnhumby.com/sourcefles
https://www.instacart.com/datasets/grocery-shopping-2017

Recommendation Algorithms：
https://www.dropbox.com/sh/7qdquluflk032ot/AACoz2Go49q1mTpXYGe0gaANa?dl=0
https://github.com/hidasib/GRU4Rec
https://github.com/kang205/SASRec
https://github.com/Woeee/FMLP-Rec
